/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTBgra {

	/**
	 *  Accepted by the &lt;format&gt; parameter of DrawPixels, GetTexImage,
	 *  ReadPixels, TexImage1D, and TexImage2D:
	 */
	public static final int GL_BGR_EXT = 0x80E0,
		GL_BGRA_EXT = 0x80E1;

	private EXTBgra() {}
}
