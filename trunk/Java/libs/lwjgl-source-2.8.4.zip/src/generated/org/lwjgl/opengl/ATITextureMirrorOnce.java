/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ATITextureMirrorOnce {

	public static final int GL_MIRROR_CLAMP_ATI = 0x8742,
		GL_MIRROR_CLAMP_TO_EDGE_ATI = 0x8743;

	private ATITextureMirrorOnce() {}
}
